clang-format -i include/argparse/*.hpp test/*.cpp samples/*.cpp
